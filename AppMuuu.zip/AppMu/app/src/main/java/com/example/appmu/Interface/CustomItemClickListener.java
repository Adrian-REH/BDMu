package com.example.appmu.Interface;

import android.view.View;

public interface CustomItemClickListener {
     void OnItemClick(View view,int position);
}
