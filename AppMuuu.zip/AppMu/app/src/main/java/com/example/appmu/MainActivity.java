package com.example.appmu;

import android.app.ActionBar;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.net.Uri;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ImageButton;
import android.widget.ListView;


import com.example.appmu.Adapter.CustomExpandibleListAdapter;
import com.example.appmu.Donaciones.Hcoin;
import com.example.appmu.Donaciones.VIP;
import com.example.appmu.Guia.Guias;
import com.example.appmu.Guia.ListaGuias;
import com.example.appmu.Guia.ListaGuias2;
import com.example.appmu.Helper.FragmentNavigationManager;
import com.example.appmu.Interface.NavigationManager;
import com.example.appmu.ListMuDona.ListaMu;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.TreeMap;


public class MainActivity extends AppCompatActivity {

    FloatingActionButton fabottom;
    SharedPreferences sharedPreferences;
    Context contexto;
    ImageButton btn_Inicio;
    Button btn_fb,btn_wp,btn_GUIAS;
    ArrayAdapter<String> adapter;

    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mDrawerToggle;
    private ExpandableListView expandableListView;
    private List<String> listTitle;
    private Map<String,List<String>> listChild;
    private NavigationManager navigationManager;
    public MainActivity() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(R.style.NoActionBar);
        Themes();
        setContentView(R.layout.activity_main);
        btn();

        ActionBar actionBar = getActionBar();

contexto =this;

        //Int view ni idea porque lo escribi
        mDrawerLayout = findViewById(R.id.drawer_layout);
        String mActivityTitle = getTitle().toString();
        expandableListView = findViewById(R.id.navList);
        navigationManager = FragmentNavigationManager.getmInstance(this);

        initItem();
        View listHeaderView = getLayoutInflater().inflate(R.layout.new_header,null,false);
        expandableListView.addHeaderView(listHeaderView);

        genData();
        addDrawerItem();
        setupDrawer();

        setTheme(R.style.NoActionBar);
        btn_Inicio = findViewById(R.id.btn_Inicio);

        btn_Inicio.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                getSupportFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                mDrawerLayout.closeDrawer(GravityCompat.START);
            }
        });




        if (savedInstanceState == null)
            selectFirstItemAsDefault();
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setTitle("AYUDA MU");



    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        mDrawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mDrawerToggle.onConfigurationChanged(newConfig);

    }

    private void selectFirstItemAsDefault() {
        if (navigationManager !=null)
        {
            String firstItem = listTitle.get(0);
            navigationManager.showFragment(firstItem);
            Objects.requireNonNull(getSupportActionBar()).setTitle(firstItem);

        }
    }

    private void btn(){
        ImageButton btn_pag = findViewById(R.id.btn_pag);


        btn_wp = findViewById(R.id.btn_wp);
        btn_fb = findViewById(R.id.btn_fb);
        btn_GUIAS = findViewById(R.id.btn_GUIAS);
        fabottom = (FloatingActionButton)findViewById(R.id.fabottom);





        btn_pag.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                //El brindamos el dato necesario a Uri
                Uri uriUrl = Uri.parse("http://tuservermu.com.ve/");
              //  Uri uriUrl = Uri.parse("http://tuservermu.com.ve/");
                //Especificamos la accion a realizar con el ACTION_VIEW
                //para que elija lo mas razonable
                Intent intent = new Intent(Intent.ACTION_VIEW, uriUrl);
                startActivity(intent);
            }
        });

        btn_fb.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                //El brindamos el dato necesario a Uri
                Uri uriUrl = Uri.parse("https://www.facebook.com/TUServerMU.com.ve/");
                //Especificamos la accion a realizar con el ACTION_VIEW
                //para que elija lo mas razonable
                Intent intent = new Intent(Intent.ACTION_VIEW, uriUrl);
                startActivity(intent);
            }
        });
        fabottom.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                Intent intent = new Intent(contexto, ViewTop.class);
                contexto.startActivity(intent);
            }
        });
        btn_wp.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
               /*  Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:+5214521767269"));
                startActivity(intent); */
                getSupportFragmentManager().beginTransaction().replace(R.id.container,
                        new ListaMu()).addToBackStack(null).commit();

            }
        });
        btn_GUIAS.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                getSupportFragmentManager().beginTransaction().replace(R.id.container,
                        new Guias()).addToBackStack(null).commit();


            }
        });

    }


    private void Themes(){

    sharedPreferences = getSharedPreferences("VALUES",MODE_PRIVATE);
    int theme = sharedPreferences.getInt("THEME",1);

    switch (theme){
        case 1: setTheme(R.style.AppTheme);

            break;
        case 2: setTheme(R.style.NoActionBar);
            break;
    }


}

    private void addDrawerItem() {
        ExpandableListAdapter adapter = new CustomExpandibleListAdapter(this, listTitle, listChild);
        expandableListView.setAdapter(adapter);

        expandableListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener(){
            @Override
            public void onGroupExpand(int groupPosition){
                Objects.requireNonNull(getSupportActionBar()).setTitle(listTitle.get(groupPosition));
            }
        });
        expandableListView.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {
            @Override
            public void onGroupCollapse(int groupPosition) {
                Objects.requireNonNull(getSupportActionBar()).setTitle("AYUDA MU");
            }
        });




        expandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {

                String selectedItem = ((List) (Objects.requireNonNull(listChild.get(listTitle.get(groupPosition)))))
                        .get(childPosition).toString();
                Objects.requireNonNull(getSupportActionBar()).setTitle(selectedItem);

                if(Objects.equals(selectedItem, "LISTA DE MU!")){
                    getSupportFragmentManager().beginTransaction().replace(R.id.container,
                            new ListaMu()).addToBackStack(null).commit();
                }
                else
               if(Objects.equals(selectedItem, "TOP MU")){
                Intent intent = new Intent(contexto, ViewTop.class);
                contexto.startActivity(intent);

                }
                else
                    if(Objects.equals(selectedItem, "GUIAS MU OFFLINE")){
                        getSupportFragmentManager().beginTransaction().replace(R.id.container,
                               new Guias()).addToBackStack(null).commit();

                    }

                        else
                            if(Objects.equals(selectedItem, "Acerca de D.Ñ.")){

                                getSupportFragmentManager().beginTransaction().replace(R.id.container,
                                        new Email()).addToBackStack(null).commit();
                    }
                        else
                            if(Objects.equals(selectedItem, "VIP")){

                                getSupportFragmentManager().beginTransaction().replace(R.id.container,
                                        new VIP()).addToBackStack(null).commit();
                            }
                            else
                                if(Objects.equals(selectedItem, "HCOIN")){
                                getSupportFragmentManager().beginTransaction().replace(R.id.container,
                                        new Hcoin()).addToBackStack(null).commit();
                            }
                            else
                                if(Objects.equals(selectedItem, "EMAIL PARA DONAR")){
                                getSupportFragmentManager().beginTransaction().replace(R.id.container,
                                        new EmailD()).addToBackStack(null).commit();
                            }
                            else
                                if(Objects.equals(selectedItem, "PROMOCION")){
                                    try{
                                        //El brindamos el dato necesario a Uri
                                        Uri uriUrl = Uri.parse("http://www.heroes-networks.com/heroes-networks/heroes-networks/donaciones/promociones");
                                        //Especificamos la accion a realizar con el ACTION_VIEW
                                        //para que elija lo mas razonable
                                        Intent intent = new Intent(Intent.ACTION_VIEW, uriUrl);
                                        startActivity(intent);
                                    }
                                    catch (Exception error){
                                        Log.e("UPDATE error", error.getMessage());
                                    }
                            }
                            else

                throw new IllegalArgumentException("Fragmento no soportado");

                mDrawerLayout.closeDrawer(GravityCompat.START);
                return false;
            }
        });
    }

    private void setupDrawer() {
        mDrawerToggle = new ActionBarDrawerToggle(this,mDrawerLayout,R.string.open,R.string.close)
        {
            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);

                invalidateOptionsMenu();
            }

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);

                invalidateOptionsMenu();
            }
        };

        mDrawerToggle.setDrawerIndicatorEnabled(true);
        mDrawerLayout.setDrawerListener(mDrawerToggle);
    }

    private void genData() {
        //LISTA DEL MENU LATERAL PARA ACCEDER A GUIAAS Y DONACIONES
        List<String> title = Arrays.asList( "•GUIA","•DONACION A UN SRV","•SRV MU");
        List<String> childitem = Arrays.asList("LISTA DE MU!","TOP MU");
        List<String> childitem2 = Arrays.asList("GUIAS MU OFFLINE","Acerca de D.Ñ.");
        List<String> childitem3 = Arrays.asList("VIP","HCOIN","PAG DE PROMOCION","EMAIL PARA DONAR");


        listChild = new TreeMap<>();

         listChild.put(title.get(2),childitem);
        listChild.put(title.get(1),childitem3);
        listChild.put(title.get(0),childitem2);




        listTitle = new ArrayList<>(listChild.keySet());
    }

    private void initItem() {
        String[] items = new String[]{ "•GUIA","•DONACION A UN SRV","•SRV MU"};
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (mDrawerToggle.onOptionsItemSelected(item))
            return true;
        return super.onOptionsItemSelected(item);

    }


}
