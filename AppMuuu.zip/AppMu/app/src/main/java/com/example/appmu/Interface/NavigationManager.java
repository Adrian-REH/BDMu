package com.example.appmu.Interface;

public interface NavigationManager {
    void showFragment(String title);

}
